package loopsassignment;
import java.util.Scanner;
public class question16 {
	 public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        int sum = 0;
	        int num;

	        do {
	            System.out.print("Enter a number (negative to stop): ");
	            num = sc.nextInt();

	            if (num >= 0) {   
	                if (num % 2 == 0) {
	                    sum += num;
	                }
	            }

	        } while (num >= 0); 
	        System.out.println("Sum of all even numbers entered: " + sum);

	      
	    }
	}

	
		   