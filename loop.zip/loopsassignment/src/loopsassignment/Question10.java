package loopsassignment;
import java.util.Scanner;

public class Question10 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);

    System.out.print("Enter a number: ");
    int num = sc.nextInt();

  
    if (num >= 100) {
        if (num <= 999) {
           
            int d1 = num / 100;          
            int d2 = (num / 10) % 10;    
            int d3 = num % 10;           

            int sum = d1 + d2 + d3;

          
            if (sum % 2 == 0) {
                System.out.println("Sum of digits is even");
            } else {
                System.out.println("Sum of digits is odd");
            }
        } else {
            System.out.println("Not a 3-digit number");
        }
    } else {
        System.out.println("Not a 3-digit number");
    }

}}

	        