package loopsassignment;
import java.util.Scanner;
public class question17 {
	 public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        System.out.print("Enter a number: ");
	        int num = sc.nextInt();
	        int divisor = 1;
	        int temp = num;
	        while (temp >= 10) {
	            temp = temp / 10;
	            divisor = divisor * 10;
	        }
	       
	        do {
	            int digit = num / divisor;   
	            System.out.print(digit + " ");

	            num = num % divisor;         
	            divisor = divisor / 10;      

	        } while (divisor > 0);

	        
	    }
	}

		   