package loopsassignment;
import java.util.Scanner;
public class Question7 {
	public static void main(String[] args) {
		 Scanner sc = new Scanner (System.in);
		System.out.print("Enter first number: "); 
		int a = sc.nextInt(); 
		System.out.print("Enter second number: "); 
		int b = sc.nextInt();
		System.out.print("Enter third number: ");
		int c = sc.nextInt();
		System.out.print("Enter fourth number: ");
		int d = sc.nextInt();
		int largest;
		
				        if (a > b) {
				            if (a > c) {
				                if (a > d) {
				                    largest = a;
				                } else {
				                    largest = d;
				                }
				            } else
				            { 
				                if (c > d) 
				                {
				                    largest = c;
				                }
				                else {
				                    largest = d;
				                }
				            }
				        } else 
				        { 
				            if (b > c) 
				            {
				                if (b > d)
				                {
				                    largest = b;
				                } else
				                {
				                    largest = d;
				                }
				            } else
				            { 
				                if (c > d)
				                {
				                    largest = c;
				                } else
				                {
				                    largest = d;
				                }
				            }
				        }

				        System.out.println("The largest number is: " + largest);

				        
				    }
				}

