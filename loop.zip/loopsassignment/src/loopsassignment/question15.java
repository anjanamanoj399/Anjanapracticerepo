package loopsassignment;
import java.util.Scanner;
public class question15 {

	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        System.out.print("Enter number of terms (N): ");
	        int N = sc.nextInt();

	        int term = 1;   
	        int diff = 1;  
	        int count = 1; 

	        while (count <= N) {
	            System.out.print(term + " ");

	          
	            term = term + diff;
	            diff++;         
	            count++;         
	        }

	        
	    }
	}
