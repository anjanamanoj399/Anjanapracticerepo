package loopsassignment;

public class question18 {

	public static void main(String[] args) {
		int a=19;
		
		do
		{
			System.out.println("Loop executed");
		}while(a < 2);

	}

}
