package loopsassignment;

public class Question22 {

    static boolean isPalindrome(int n) {
        int original = n;
        int reversed = 0;
        
        while (n > 0) {
            int digit = n % 10;
            reversed = reversed * 10 + digit;
            n /= 10;
        }
        
        return original == reversed;
    }

    public static void main(String[] args) {
        int largestPalindrome = -1;

     
        for (int i = 100; i <= 999; i++) {
            if (isPalindrome(i)) {
                largestPalindrome = i; 
            }
        }

        System.out.println("Largest palindrome between 100 and 1000 is: " + largestPalindrome);
    }
}

	
	
		    
		   