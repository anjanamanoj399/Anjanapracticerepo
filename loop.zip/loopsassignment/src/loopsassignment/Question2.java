package loopsassignment;


public class Question2 {

	public static void main(String[] args) {
		int a=96,d=6,g=86;
		int secondlargest;
		
		if ((a>d && a<g) || (a<d && a>g)) {
			secondlargest =a;
			System.out.println("secondlargest :"+secondlargest);
	}
	else if( (d>a && d<g) || (d<a && d>g)) {
			secondlargest =d;
		
			System.out.println("secondlargest:"+secondlargest);
		
			}
			else {
			secondlargest =g;
			System.out.println("secondlargest :"+secondlargest);
		}
	}
	
}
