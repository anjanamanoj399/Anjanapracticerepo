package loopsassignment;
import java.util.Scanner;
public class question14 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);

	        System.out.print("Enter number of terms (N): ");
	        int N = sc.nextInt();

	        int first = 0, second = 1;

	        int count = 1; 

	        while (count <= N) {
	            System.out.println(first);

	            if (first > 500) {
	                break;
	            }

	            int next = first + second;
	            first = second;
	            second = next;

	            count++;
	        }

	       
	    }
	}
	       