package loopsassignment;
import java.util.Scanner;

public class Question6 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner (System.in);
		
			
			System.out.println("enter the maths mark");
			int maths  =sc.nextInt();
			System.out.println("enter the physics mark");
			int physics  =sc.nextInt();
			System.out.println("enter the chemistry mark");
			int chemistry  =sc.nextInt();
			int total  = maths + physics+ chemistry;
			
			
			if (maths >= 60 && physics >= 50 && chemistry >= 40 && 
					(total >= 180 || (maths + physics) >= 120))
{
	System.out.println (" Student is eligible");
	
	}
					
	else {
	System.out.println (" Student is not eligible");
}}

}


