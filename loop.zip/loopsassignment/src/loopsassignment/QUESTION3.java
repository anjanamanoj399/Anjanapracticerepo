package loopsassignment;
import java.util.Scanner;

public class QUESTION3 {

	public static void main(String[] args) {
		
		// year divisible by 400
		//year divisible by 4 and not 100
		Scanner sc = new Scanner (System.in);
		
		System.out.println("enter the year");
		int year =sc.nextInt();
		
		if( (year % 400==0)||((year % 4==0) && (year % 100 !=0)))
		{ 
		
			System.out.println ("Leap year");
		
	}
		else {
			System.out.println (" Not Leap year");

}
	}
}