package loopsassignment;

public class question13 {

	public static void main(String[] args) {
		int num=56933287;
		int count=0;
		
		while(num>0)
		{
			int digit=num % 10;
			
			if(digit==5 || digit==3 ||digit==7) {
				count++;
			}
			num=num/10;
		}
		
		System.out.println("Count of prime numbers in an entered number is " +count);
	}

}


