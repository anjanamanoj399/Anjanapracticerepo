package loopsassignment;
import java.util.Scanner;

public class Question5 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner (System.in);
			
			System.out.println("enter the number");
			int number =sc.nextInt();
			if (number % 2==0) {
					if (number % 3==0)
						
			{ 
				System.out.println ("a");
			}
					else {
						System.out.println ("c");
					}}
					else 	
						if (number % 3==0) {
							if (number % 2!=0)
								
					{ 
					
						System.out.println ("b");
					}
						}else {
								System.out.println ("d");
							}
	

						}
					
			
	}
