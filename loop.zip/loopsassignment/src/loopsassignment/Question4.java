package loopsassignment;
import java.util.Scanner;


public class Question4 {

	public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
		
		System.out.println("enter the number");
		int number =sc.nextInt();
		if( (number >0 && number % 4==0)||(number<0 && number % 6 ==0 ))
		{ 
		
			System.out.println ("Condition satified");
		}
			
		else {
			System.out.println (" Condition is not satified");
			}
	}

	}


