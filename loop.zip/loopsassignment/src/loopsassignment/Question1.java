package loopsassignment;

public class Question1 {

	public static void main(String[] args) {
		int num=33;
		if(num % 3==0 && num % 5!=0 && num>=50 && num<=200)
		{
			System.out.println("valid");
		}
		else
		{
			System.out.println("invalid");
		}
		
	}

}
