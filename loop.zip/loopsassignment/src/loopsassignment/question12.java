package loopsassignment;
import java.util.Scanner;
public class question12 {

	public static void main(String[] args) {
	
{   Scanner sc = new Scanner(System.in);

System.out.print("Enter a number: ");
int num = sc.nextInt();

int reversed = 0;
boolean stopped = false;

while (num > 0) {
    int digit = num % 10;   

    if (digit == 0) {
        stopped = true;
        break;             
    }

    reversed = reversed * 10 + digit;
    num = num / 10;      
}

if (stopped) {
    System.out.println("Stopped reversing because digit 0 was encountered.");
    System.out.println("Partial reversed number: " + reversed);
} else {
    System.out.println("Reversed number: " + reversed);
}



}}}
		    
		     