package loopsassignment;

public class question11 {
	 public static void main(String[] args) {
	        int i = 1;

	        while (i <= 100) {
	            
	            if (i == 77) {
	                break;
	            }

	            
	            if (i % 3 == 0) {
	                if (i % 5 == 0) {
	                    i++; 
	                    continue;
	                }
	            }

	            System.out.println(i);

	            i++;
	        }
	    }
	}
	
	