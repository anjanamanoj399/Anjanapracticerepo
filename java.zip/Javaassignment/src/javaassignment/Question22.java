package javaassignment;

class GovernmentRules {
	
	  final int MAX_WORKING_HOURS = 8;
		
	GovernmentRules(int m){
		var  MAX_WORKING_HOURS=m;
	}

	void method() {
		
		System.out.println(MAX_WORKING_HOURS);
	}
		
	}


public class Question22 {


		
	public static void main(String[] args) {
		GovernmentRules obj = new GovernmentRules(10);
		obj.method();
		}

	}
