package javaassignment;

class Device {

	void start() {
		System.out.println("Start the Device");
	}
	
}

class Mobile extends Device {
	
	void calling () {
		System.out.println("Mobile is connecting for calling");
	}
}

class SmartPhone extends Mobile{
	
	void internet () {
		System.out.println("SmartPhones requires Internet to access");
	}
}


public class Question13 {

	public static void main(String[] args) {
		
		SmartPhone obj = new SmartPhone();
		obj.start();
		obj.calling();
		obj.internet();

	}

}
