package javaassignment;

class Library{
	
	String libraryName="State Library";
	
	Library(){
		
		System.out.println("Welcome to the Library!");
	}
	
	void showLocation(){
		System.out.println(libraryName+" "+": This Library is located in Mumbai");
	}
}


public class Question11 {

	
		public static void main(String[] args) {
			
			Library obj = new Library();
			obj.showLocation();

		}

	}