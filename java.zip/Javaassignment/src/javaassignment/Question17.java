package javaassignment;

abstract class Employee1 {
	
void employeeDetails() {
		
	System.out.println("Parttime Employee Name: ARYA");
	System.out.println("Fulltime Employee Name: SREE");
	System.out.println();
		
	}
abstract double calculateSalary(int a, double b);

}


class ParttimeEmployee extends Employee1 {

double calculateSalary(int totalworkinghoursperday, double salaryPerHour) {
	return(totalworkinghoursperday*salaryPerHour);
	
}

}

class FulltimeEmployee extends Employee1 {

double calculateSalary(int totalworkingdayspermonth, double salaryPerDay) {
	return(totalworkingdayspermonth*salaryPerDay);
	
}


}
public class Question17 {
	
public static void main(String[] args) {
		
		
		Employee1 ref = new ParttimeEmployee();
		Employee1 ref1 = new FulltimeEmployee();
		
		ref.employeeDetails();
		System.out.println("ARYA Salary is: "+ ref.calculateSalary(1,800)+"  "+ "Per Day");
		System.out.println("SREE Salary is: "+ ref1.calculateSalary(30,1600)+"  "+"Per Month");
	
		
		
		
	}

}
