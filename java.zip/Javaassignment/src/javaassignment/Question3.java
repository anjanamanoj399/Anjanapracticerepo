package javaassignment;

class Product {
	
	int ProductID;
	String ProductName;
	double ProductPrice;
	
	Product()  {
		
		System.out.println("Product Created");
	}
	
	Product(int i, String c, double u) {
		ProductID=i;
		ProductName=c;
		ProductPrice=u;		
		
	}
	
	void displayProduct() {
		
		System.out.println("Product ID: "+ ProductID);
		System.out.println("Product Name: "+ ProductName);
		System.out.println("Product Price: "+ ProductPrice);
	}
}
	


public class Question3 {

	public static void main(String[] args) {

		Product obj = new Product();
		Product obj1 = new Product(567,"soap",15);
		obj1.displayProduct();
		

	}

	}


