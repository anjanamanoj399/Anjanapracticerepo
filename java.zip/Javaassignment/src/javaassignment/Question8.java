package javaassignment;

class Shape{
	
	void area() {
		System.out.println("Shape class");
	}
	
}
class Circle extends Shape {
	
	
	void area() {
	System.out.println(" Class Circle"); 
	}
}

class Rectangle extends Shape {
	
	
	void area() {
		System.out.println(" Class Rectangle");
	}
}



public class Question8 {

	public static void main(String[] args) {
		
Shape ref;
ref = new Circle();
ref.area();
ref = new Rectangle();
ref.area();

}

}