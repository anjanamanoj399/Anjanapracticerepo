package javaassignment;

abstract class Animal{
	
	abstract void sound();
	
}
	
class Dog extends Animal {
	
	void sound() {
		System.out.println("Dog sound: Bark");
	}
	
}	
class Cat extends Animal {
	
	void sound() {
		System.out.println("Cat sound: Meow");
	}
}	
	

	
public class Question5 {

public static void main(String[] args) {
		
		Dog obj = new Dog();
		Cat obj1 = new Cat();
	    obj.sound();
		obj1.sound();

	}

}
