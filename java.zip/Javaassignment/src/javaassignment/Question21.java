package javaassignment;

class University {
	
	static String country = "India";
	String universityName;
	
 University(String U) {
	 
	 universityName=U;
 }
	
	void toPrint() {
		System.out.println(universityName+", "+"Location: "+ country);
	}
	
}
public class Question21 {

	public static void main(String[] args) {
		University obj = new University("KTU University");
		obj.toPrint();
		University obj1 = new University("Calicut University");
		obj1.toPrint();
		University obj2 = new University("MG University");
		obj2.toPrint();
		University obj3 = new University("SRM University");
		obj3.toPrint();
		University obj4 = new University("Christ University");
		obj4.toPrint();
	}

}