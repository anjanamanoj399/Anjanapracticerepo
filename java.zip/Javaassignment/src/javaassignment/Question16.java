package javaassignment;

class Hospital{
	
	void emergencyService(){
		System.out.println("Our hospital provides 24/7 Emergency Services");	
}
}
class CityHospital extends Hospital{
	
	void emergencyService(){
		System.out.println(" 24/7 EmergencyService available at CityHospital");
		super.emergencyService();	
}
}

public class Question16 {

	public static void main(String[] args) {
		
		CityHospital obj = new CityHospital();
		obj.emergencyService();

	}

}