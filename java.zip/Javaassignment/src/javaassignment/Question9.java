package javaassignment;

class Bank { final String a = "IFSC"; 
final void showIFSC()
{
	System.out.println(a);
} 


} 
class HDFCBANK extends Bank
{ 
	void showBranchIFSC()
	{ 
		System.out.println("HDFC Bank IFSC Code: HDFC000135");
	}
	
}
public class Question9 {

	public static void main(String[] args) {
		
	 Bank ref = new HDFCBANK(); 
		ref.showIFSC(); 
		HDFCBANK hdfc = new HDFCBANK();
		hdfc.showBranchIFSC();
		} 
	}