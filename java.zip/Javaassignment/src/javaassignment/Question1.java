package javaassignment;
class Employee {
	
	private int empID;
	private String empName;
	private float salary;
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	
	void displayDetails() {
		
		System.out.println("Employee ID: "+ empID);
		System.out.println("Employee Name: "+ empName);
		System.out.println("Employee Salary: "+ salary);
		
	}
	
}

public class Question1 {

	public static void main(String[] args) {
	
			
			Employee obj = new Employee();
			obj.setEmpID(5678);
			obj.setEmpName("Anjana");
			obj.setSalary(50000);
			obj.displayDetails();


	}

}
