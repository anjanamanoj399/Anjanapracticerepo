package javaassignment;

class Mall {

	
	Mall() {
		System.out.println("Welcome to the Mall");
	}
	
	Mall(String c ){
		
	this();
	System.out.println("Constructors Chained");
	}
	
}

public class Question23 {

	public static void main(String[] args) {
		Mall obj = new Mall("Hilite");

	

	}

}
