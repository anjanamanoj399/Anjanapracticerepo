package javaassignment;

class LoanCalculator{
	
	
	int calculateLoan (int amount) {
		
		return amount;
	}
	
	double calculateLoan (int amount, double interestRate) {
	      return amount + (amount*(interestRate/100));
		  
	}
	
}
public class Question15 {

	public static void main(String[] args) {
		LoanCalculator obj = new LoanCalculator();
		System.out.println("Loan Amount: "+obj.calculateLoan(500000));
		System.out.println("Overall Payback Amount(Includes Interest): "
				+ ""+obj.calculateLoan(500000, 8.0));

	}

}