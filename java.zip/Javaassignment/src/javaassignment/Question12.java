package javaassignment;

class Account {
	
	private String accountHolderName;
	private double balance;
	
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance){
		
		if (balance<0) {
			System.out.println(" Warning :Values cannot be negative and they are not accepted !");
		} else {
			System.out.println("Available Balance: "+ balance);
		}
		this.balance = balance;
	}
	
	
}

public class Question12 {

	public static void main(String[] args) {
		
			Account obj = new Account();
			obj.setAccountHolderName("Anjana");
			System.out.println("Acccount Holder Name: "+obj.getAccountHolderName());
			obj.setBalance(-2000);

	}

}
