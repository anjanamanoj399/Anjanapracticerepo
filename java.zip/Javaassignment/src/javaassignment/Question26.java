package javaassignment;

class SchoolA {
	
	String name;
	String address;
	String strength;
	
	SchoolA(String name,String address){
	this.name=name;
	this.address=address;
	}		
	
	SchoolA(String name,String address, String strength){
		this(name, address);
		this.strength=strength;
	}
		
	void display() {
		System.out.println(name+" "+address+" "+strength);
	}
}
public class Question26 {
	public static void main(String[] args) {
		
	       SchoolA obj = new SchoolA("VGHSS","THRISSUR");
	       SchoolA obj1 = new SchoolA("VGHSS","THRISSUR","60");
		   obj.display();
		   obj1.display();
		}

	}

