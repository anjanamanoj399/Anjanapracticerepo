package javaassignment;

class Course{
	
	void courseInfo() {
		System.out.println("Course infomration are given below:");
	}
}
class Commerce extends Course {
	
	void Commerceinfo() {
		System.out.println("Commerce Syllabus");
	}
}


class Science extends Course{
	
	void Scienceinfo() {
		System.out.println("Science syllabus");
	}
}


class Art extends Course{
	
	void artinfo() {
		System.out.println("Art Syllabus");
	}
}

public class Question14 {

	public static void main(String[] args) {
		
		Course obj = new Course();
		obj.courseInfo();
		Commerce obj1 = new Commerce();
		obj1.Commerceinfo();
		Science obj2 = new Science();
		obj2.Scienceinfo();
		Art obj3 = new Art();
		obj3.artinfo();
		

	}

}