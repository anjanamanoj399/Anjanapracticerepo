package javaassignment;

class Student1{
	
	static String collegename = "VAST";
	String name;
	int rollno;
	
	void display() {
		System.out.println("College name : " +collegename + " "+ "Student name :"+ 
	name + " "+ "Student rollno :" + rollno );
	}
}

public class Question10 {

	public static void main(String[] args) {
		
		
		Student1 obj = new Student1();
		obj.name="SREE";
		obj.rollno =2;
		obj.display();
		
		Student1 obj1 = new Student1();
         obj1.name="ARYA";
         obj1.rollno=4;
         obj1.display();
         
         Student1 obj2 = new Student1();
         obj2.name="RIYA";
         obj2.rollno=61;
         obj2.display();
         
         Student1 obj3 = new Student1();
         obj3.name="DEVU";
         obj3.rollno=10;
         obj3.display();
         
	}

}


